# Gray_Image_Reader

Gray image processor

10:11 4
GraphicsAssignmentS4.
Submission Instructions:
Assignment Instructions:
Please carefully read the instructions for  S2 and strictly follow these
instructions. Failure to follow the instructions might result in a penalty (rather than
getting a grade of 1 and a chance to remedul
you cannot use any GLU or GLUT functions for defining objects such as the
cube or the sphere (you can use the sphere snippet posted on Canvas).
From this assignment and on, I will am giving extra points 4 this time) to students that exceed
the requirements posed in the assignments. For example, adding animation, texture mapping
fractals. or other "nice" teatures
Assignment Instructions:
The goal of this assignment (S4, is to expand the scene you produced in assignment S2.
The Canvas folder "Misc./PPM.zip" contains: a program that enables loading a PPM image into
the trame butter, several PPM images, a tew PGMA images, and the PGMA file format detinition.
Note that the PPM-read function is specific to a PPM header format and not all the images
comply with this format. Hence, either the image header or PPM-read might need to be
changed accordingly. Note that the program is using C constructs for file 1/0. You can use the
program as is or replace the C constructs bv C++ constructs.
A computer-generated image is the contents of the frame buffer of any graphics vou generate
using an open GL program.
A natural image is any decent image (assume rated G in terms of movies) you load from the
internet or from Canvas. The image can be in any image format (e.g., tiff, jpeg, PPM). It is
recommended that you use a PPM or PGMA images or convert your image to PPM.
The main requirement of this assignment Is to exercise GL texture mapping. In specific:
At the minimum, your scene should include the following the following objects: a triangle, a
square, a hexagon, a cube, a sphere, a cylinder, and the walls of a "room" where your
scene "resides"
Use perspective prolection and place the items with minimum occlusion and awav from the
deniel
Add texture mapping effects to your current scene.
Add at least six different texture effects to objects in your scene (one per object)
At least two of the images used for mapping should be a natural images.
At least one image should be in PPM format
At least one image should be in PG or PGMA format
Extra credit - At least one of the images used for mapping should be a
computer-generated image a tractal, a chess-board, a synthetic image or a
Tlag, a sine wave, etc.)
Dashboard
Calendar
TO Do
Notifications
Inbox
